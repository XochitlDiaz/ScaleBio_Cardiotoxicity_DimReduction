"""
PCA, neighbor graph, UMAP, and Leiden clustering.
"""
from __future__ import annotations

import logging

import anndata as ad
import scanpy as sc

log = logging.getLogger(__name__)


def run_pca(adata: ad.AnnData) -> ad.AnnData:
    sc.pp.pca(adata, svd_solver="arpack", use_highly_variable=True, layer="log1p_norm")
    log.info(f"PCA computed: {adata.obsm['X_pca'].shape[1]} components.")
    return adata


def run_neighbors(adata: ad.AnnData, n_pcs: int, n_neighbors: int) -> ad.AnnData:
    sc.pp.neighbors(adata, n_pcs=n_pcs, n_neighbors=n_neighbors)
    log.info(f"Neighbor graph built (n_pcs={n_pcs}, n_neighbors={n_neighbors}).")
    return adata


def run_umap(adata: ad.AnnData) -> ad.AnnData:
    sc.tl.umap(adata)
    log.info("UMAP embedding computed.")
    return adata


def run_leiden(adata: ad.AnnData, resolution: float, key_added: str) -> ad.AnnData:
    """Run Leiden and store labels in adata.obs[key_added] as a categorical."""
    sc.tl.leiden(adata, resolution=resolution, key_added=key_added)
    adata.obs[key_added] = adata.obs[key_added].astype("category")
    n_clusters = adata.obs[key_added].nunique()
    log.info(
        f"Leiden clustering @ resolution={resolution}: "
        f"{n_clusters} clusters -> adata.obs['{key_added}']"
    )
    return adata
