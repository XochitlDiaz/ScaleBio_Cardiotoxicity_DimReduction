"""
Central configuration for the scRNA-seq dim-reduction pipeline.

Edit paths / thresholds here; everything else imports from this module.
"""
from pathlib import Path

# -----------------------------------------------------------------------------
# Paths
# -----------------------------------------------------------------------------
H5AD_LIST_PATH = Path(
    "/g/data/wy83/cardiotoxicity/analysis/anndata/full_data_analysis/"
    "dim_reduction/code/ScaleBio_h5ad_file_paths.txt"
)

METADATA_TSV_1 = Path(
    "/g/data/wy83/cardiotoxicity/analysis/anndata/data/Toxcicity/ScaleBio/"
    "Cardiotoxicity_per_cell_metadata.tsv"
)

METADATA_TSV_2 = Path(
    "/g/data/wy83/cardiotoxicity/analysis/anndata/BioTuring/TBD_metadata.tsv"
)
METADATA_TSV_2_COLS = [0, 1, 22]  # columns to read from TSV_2

SAVE_PATH = Path(
    "/g/data/wy83/cardiotoxicity/analysis/anndata/full_data_analysis/"
    "dim_reduction/results"
)
FIGDIR = SAVE_PATH / "figures"
CSV_EXPORT_PATH = SAVE_PATH / "full_csv_exports"
PER_BATCH_DIR = SAVE_PATH / "per_sample_adata"

# Optional Ensembl -> gene-symbol mapping (TSV with two columns: ensembl_id, symbol)
# Leave as None if adata.var already has a symbol column (see VAR_SYMBOL_COL_CANDIDATES)
ENSEMBL_TO_SYMBOL_TSV: Path | None = None
VAR_SYMBOL_COL_CANDIDATES = ("feature_name", "gene_symbols", "gene_symbol",
                             "symbol", "gene_name", "Symbol")

# -----------------------------------------------------------------------------
# Compute
# -----------------------------------------------------------------------------
N_JOBS = 16
RANDOM_SEED = 42

# -----------------------------------------------------------------------------
# Filtering thresholds
# -----------------------------------------------------------------------------
BAD_VILLAGES = ["Village_21", "Village_27"]
MIN_GENES_PER_CELL = 2000
MIN_CELLS_PER_GENE = 20
MAX_PCT_MT = 6.0

# -----------------------------------------------------------------------------
# Column names
# -----------------------------------------------------------------------------
# Which obs column carries the batch label to split on when exporting per-batch.
# After the metadata join this may end up as "Batch" or "Batch_meta" depending
# on whether the original adata.obs already had "Batch". The metadata module
# resolves this and stores the final name in adata.uns["batch_col"].
BATCH_COL_CANDIDATES = ("Batch_meta", "Batch")

# Leiden clustering key stored in adata.obs after running the leiden step.
LEIDEN_RESOLUTION = 0.5
LEIDEN_KEY = f"leiden_r{LEIDEN_RESOLUTION}"

# -----------------------------------------------------------------------------
# Dim reduction
# -----------------------------------------------------------------------------
N_PCS_FOR_NEIGHBORS = 30
N_NEIGHBORS = 15

# -----------------------------------------------------------------------------
# Subsetting
# -----------------------------------------------------------------------------
SUBSET_DENOMINATOR = 16  # keep n_cells // 16 cells at random

# -----------------------------------------------------------------------------
# UMAP covariates to colour by (each becomes one saved figure)
# -----------------------------------------------------------------------------
UMAP_COVARIATES = [
    "Batch_meta",              # will fall back gracefully if the col doesn't exist
    "sample_id",
    "ct_cardiovascular_disease",
    "village_id",
    "Donor_ID",
    "pct_counts_mt",
    "n_genes_by_counts",
    "total_counts",
]

# -----------------------------------------------------------------------------
# Mitochondrial genes (Ensembl IDs, since var_names are Ensembl)
# -----------------------------------------------------------------------------
MT_GENES_TO_ENSEMBL = {
    "MT-ND1":  "ENSG00000198888",
    "MT-ND2":  "ENSG00000198763",
    "MT-CO1":  "ENSG00000198804",
    "MT-CO2":  "ENSG00000198712",
    "MT-ATP8": "ENSG00000228253",
    "MT-ATP6": "ENSG00000198899",
    "MT-CO3":  "ENSG00000198938",
    "MT-ND3":  "ENSG00000198840",
    "MT-ND4L": "ENSG00000212907",
    "MT-ND4":  "ENSG00000198886",
    "MT-ND5":  "ENSG00000198786",
    "MT-ND6":  "ENSG00000198695",
    "MT-CYB":  "ENSG00000198727",
}

# -----------------------------------------------------------------------------
# Marker gene groups (symbols; converted to Ensembl at plot time)
# -----------------------------------------------------------------------------
MARKER_GROUPS = {
    "Endothelium": [
        "PCDH12", "CDH5", "CD93", "PECAM1", "VIP", "DIPK2B", "MYCT1", "CD34",
        "GIMAP4", "PIK3CG", "RASGRP3", "ROBO4", "TAL1", "BTNL9", "AC114757.1",
    ],
    "Glial": [
        "SOX10", "CDH19", "S100B", "PRSS56", "MPZ", "INSC", "PLP1", "CHRND",
        "FOXD3", "GPR17", "ATP10B", "ERBB3", "ROPN1B", "AC099489.1", "MOXD1",
    ],
    "Mesenchymal": [
        "AC093849.1", "TCF21", "AP003555.2", "AC103702.2", "HAND2", "HAND2-AS1",
        "HOXA13", "RXFP2", "HAND1", "HOXA10", "TARID", "FOXF1", "CCN4",
        "CCDC68", "AC103702.1",
    ],
    "Fibroblasts": [
        "CRYM", "LINC02188", "SLC9A9-AS1", "FOXD1", "AC009154.1", "PRRX1", "MKX",
        "AC116563.1", "LAMA4", "Z99289.2", "FAP", "AC018450.1", "ARHGAP20",
        "CPED1", "ABCA9",
    ],
    "Neurons": [
        "SLC17A6", "DRGX", "NEUROD1", "LINC02487", "STMN2", "UNCX", "AC010247.2",
        "AC091980.2", "AL031658.2", "PHOX2B-AS1", "NEUROD4", "XKR7", "TH",
        "ADCYAP1", "LINC00682",
    ],
    "Neuron Progenitors": [
        "WNT1", "WNT3A", "WNT7A", "RFX4", "AL359091.1", "WNT8B", "ILDR2",
        "WNT10B", "EFCC1", "C6orf118", "RMST", "KCNK10", "PAX7", "OLIG3", "WNT7B",
    ],
    "Epithelium": [
        "GRHL2", "ESRP1", "PRSS22", "TMPRSS4", "ARHGEF38", "TP63", "CDH1",
        "TACSTD2", "ZNF750", "VGLL1", "MACC1", "MUC15", "COL17A1", "CLDN4",
        "MAB21L4",
    ],
    "Cardiac muscle": [
        "MYH6", "TTN", "LRRC10", "MYBPC3", "XIRP1", "SMYD1", "MIR133A1HG",
        "AC020909.2", "TNNT2", "AC022916.2", "LMOD2", "BANCR", "UNC45B",
        "AL136171.2", "PLN",
    ],
}
